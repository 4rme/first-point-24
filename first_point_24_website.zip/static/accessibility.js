
function toggleAccessibility() {
    document.body.classList.toggle('accessibility-mode');
}
